import pandas as pd
import numpy as np
import csv
import json
from pyecharts.charts import Map
from pyecharts import options as opts

with open("USA.json", 'r') as f:
    text = json.load(fp=f)

    data = pd.read_csv('daily.csv')
    col_12 = data[['state', 'positive']]
    data_12= np.array(col_12)
    data_111 = []
    for i in range(56):
        data_111.append(data_12[i])
    df= pd.DataFrame(data_111)
    df.to_csv('usa_positive.csv', index=False)
    map_1= csv.reader(open("usa_positive.csv"))
    MAP_DATA = []
    for mp in map_1:
        MAP_DATA.append(mp)
    del MAP_DATA[0]
NAME_MAP_DATA = {
        "Alabama": "AL",
        "Alaska": "AS",
        "Arkansas": "AR",
        "Arizona": "AZ",
        "California": "CA",
        "Colorado": "CO",
        "Connecticut": "CT",
        "Washington.D.C": "DC",
        "Delaware": "DE",
        "Florida": "FL",
        "Georgia": "GA",
        "Hawaii": "HI",
        "Iowa": "IA",
        "Idaho": "ID",
        "Illinois": "IL",
        "Indiana": "IN",
        "Kansas": "KS",
        "Kentucky": "KY",
        "Louisiana": "LA",
        "Massachusetts": "MA",
        "Maryland": "MD",
        "Maine": "ME",
        "Michigan": "MI",
        "Minnesota": "MN",
        "Missouri": "MO",
        "Mississippi": "MS",
        "Montana": "MT",
        "North Carolina": "NC",
        "North Dakota": "ND",
        "Nebraska": "NE",
        "New Hampshire": "NH",
        "New Jersey": "NJ",
        "New Mexico": "NM",
        "Nevada": "NV",
        "New York": "NY",
        "Ohio": "OH",
        "Oklahoma": "OK",
        "Oregon": "OR",
        "Pennsylvania": "PA",
        "Rhode Island": "RI",
        "South Carolina": "SC",
        "South Dakota": "SD",
        "Tennessee": "TN",
        "Texas": "TX",
        "Utah": "UT",
        "Virginia": "VA",
        "Vermont": "VT",
        "Washington": "WA",
        "Wisconsin": "WI",
        "West Virginia": "WV",
        "Wyoming": "WY",
        "Puerto Rico": "PR",
        "Guam": "GU",
        "AS": "AS",
        "Northern Mariana Islands": "MP",
    }
map=(
        Map(init_opts=opts.InitOpts(width="1400px", height="800px",page_title='USA_positive'))
        .add_js_funcs("echarts.registerMap('USA', {})".format(text))
        .add(
            series_name="Positive_number",
            data_pair=MAP_DATA,
            maptype='USA',
            is_selected=True,
            name_map=NAME_MAP_DATA,
            is_map_symbol_show=False
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(
                title="美国疫情情况",
                subtitle="截止至2020年5月20日美国疫情数据"
            ),
            visualmap_opts=opts.VisualMapOpts(
                min_=0,
                max_=354370,
                range_text=["High", "Low"],
                is_calculable=True,
                range_color=["lightskyblue", "yellow", "orangered"]
            )
        )
        .render('USA_positive.html')
    )

