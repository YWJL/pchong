import pandas as pd
import csv
import pyecharts.options as opts
from pyecharts.charts import Line



df=pd.read_csv('daily.csv')
df_sum = df.groupby('date')['positive'].sum()
a=pd.read_csv('data_1.csv')
date_1=[k for k in a['date']]
positive_1=[v for v in a['positive']]
date_2=[]
for i in date_1:
    i=str(i)
    str_1=i[4:6]+'-'+i[6:]
    date_2.append(str_1)
x_data = date_2
y_data = positive_1

(
    Line(init_opts=opts.InitOpts(width="1100px", height="700px",page_title='Positive_situation'))
    .add_xaxis(xaxis_data=x_data)
    .add_yaxis(
        series_name="Cumularive Cases",
        y_axis=y_data,
        is_smooth=True,
        label_opts=opts.LabelOpts(is_show=False),
        linestyle_opts=opts.LineStyleOpts(width=4),
        color='blue'
    )
    .set_global_opts(

        title_opts=opts.TitleOpts(title="Positive_situation"),
        tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross"),
        xaxis_opts=opts.AxisOpts(boundary_gap=False),
        yaxis_opts=opts.AxisOpts(
            name='Cumularive Cases',
            axislabel_opts=opts.LabelOpts(formatter="{value}"),
            splitline_opts=opts.SplitLineOpts(is_show=True),
        ),
        visualmap_opts=opts.VisualMapOpts(
            is_show=False,
            range_color='brown',
            dimension=0,
        ),

    )
    .render("Positive_situation.html")
)
