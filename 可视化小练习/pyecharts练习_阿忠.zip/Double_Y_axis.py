import csv
import pandas
import pyecharts.options as opts
from pyecharts.charts import Line


def get_csv_data(path):
    data_positive_first = []
    data_negative_first = []
    state_first = []
    with open(path, "r") as f:
        L = list(csv.reader(f))
        for i, line in enumerate(L):
            if i == 0:
                continue
            else:
                # print("正在处理第{}行数据".format(i))
                state_first.append(line[1])
                data_positive_first.append(line[2])
                data_negative_first.append(line[3])

    data_positive_last = []
    data_negative_last = []
    # 筛选出“WA”州的数据
    for i in range(len(state_first)):
        if state_first[i] == "WA":
            data_positive_last.append(data_positive_first[i])
            data_negative_last.append(data_negative_first[i])
    return data_positive_last, data_negative_last


def Draw_data_Line(data_pocess, dates_list):
    line1 =(
        Line()
        .set_global_opts(
            title_opts=opts.TitleOpts(title="Washington Epidemic situation"),
            tooltip_opts=opts.TooltipOpts(trigger="axis", axis_pointer_type="cross", is_show=True),
            xaxis_opts=opts.AxisOpts(
                type_="category",
                axistick_opts=opts.AxisTickOpts(is_align_with_label=True),
                axispointer_opts=opts.AxisPointerOpts(is_show=True, type_="shadow")
            ),
            yaxis_opts=opts.AxisOpts(
                type_="value",
                name="Positive Cases",
                min_=0,
                max_=20000,
                interval=5000,
                axistick_opts=opts.AxisTickOpts(is_show=False),
                axisline_opts=opts.AxisLineOpts(linestyle_opts=opts.LineStyleOpts(color="red")),
                splitline_opts=opts.SplitLineOpts(is_show=True),
            ),
        )
        .add_xaxis(xaxis_data=dates_list)
        .add_yaxis(
            series_name="Positive Cases",
            # color="#5793f3",
            y_axis=data_pocess[0],
            linestyle_opts=opts.LineStyleOpts(width=3, color="red"),
            symbol="emptyCircle",
            is_symbol_show=False,
            label_opts=opts.LabelOpts(is_show=False),
        )
        .extend_axis(
            yaxis=opts.AxisOpts(
                name="Negation Cases",
                type_="value",
                min_=0,
                max_=300000,
                interval=75000,
                # position="right",
                axisline_opts=opts.AxisLineOpts(linestyle_opts=opts.LineStyleOpts(color="#5793f3"))
            )
        )
    )
    line2 = (
        Line()
        .add_xaxis(xaxis_data=dates_list)
        .add_yaxis(
            series_name="Negative Cases",
            yaxis_index=1,
            y_axis=data_pocess[1],
            is_symbol_show=False,
            linestyle_opts=opts.LineStyleOpts(width=3, color="#5793f3"),
            label_opts=opts.LabelOpts(is_show=False)
        )
    )
    line1.overlap(line2).render("Line_try2.html")


if __name__ == '__main__':
    path = "daily.csv"
    data = (get_csv_data(path))
    data_pocess = []
    positive = []
    negative = []
    for i in range(0, 57):
        positive.append(data[0][i])
        negative.append(data[1][i])
    positive.reverse()
    negative.reverse()
    data_pocess.append(list(map(int, positive)))
    data_pocess.append(list(map(int, negative)))
    list_len = len(data_pocess[0])
    dates = pandas.date_range(end='20200520', periods=list_len)
    dates_list = [date.strftime('%m-%d') for date in dates]
    Draw_data_Line(data_pocess, dates_list)
    print("Finished All")

